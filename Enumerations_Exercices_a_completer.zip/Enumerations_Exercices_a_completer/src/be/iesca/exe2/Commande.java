package be.iesca.exe2;
import be.iesca.exe2.CommandeImpl.EtatCommande;

public interface Commande {
	double montantTotalCommande();

	double montantTotalPaye();

	double soldeAPayer();

	void encaisserPaiement(double montant);

	void ajouterArticle(Article article, int quantite);

	void cloturer();

	void livrer();

	EtatCommande getEtatCommande();

}
