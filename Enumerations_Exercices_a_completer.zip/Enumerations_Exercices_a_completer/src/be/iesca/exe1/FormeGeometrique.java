package be.iesca.exe1;

public enum FormeGeometrique {
	RECTANGLE

}
